#Changelog

## 7.1.0 (2016-6-22)

### 增加
* 增加多机房相关功能

## 7.0.5 (2015-11-20)

### 增加
* add delimiter support to Bucket.List
* 增加回调校验

## 7.0.4 (2015-09-03)

### 增加
* 上传返回参数PutRet增加PersistentId，用于获取上传对应的fop操作的id

### 修复
* token 覆盖问题

## 7.0.3 (2015-07-11)

### 增加
* support NestedObject

## 7.0.2 (2015-07-7-10)

### 增加
* 增加跨空间移动文件(Bucket.MoveEx)

## 7.0.1 (2015-07-7-10)

### 增加
* 完善 PutPolicy：支持 MimeLimit、CallbackHost、CallbackFetchKey、 CallbackBodyType、 Checksum

## 7.0.0 (2016-06-29)

* 重构，初始版本
